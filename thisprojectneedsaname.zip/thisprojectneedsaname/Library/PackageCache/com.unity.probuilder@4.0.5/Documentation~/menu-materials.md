# Materials

Use this sub-menu to apply specific Material presets to the selection.

![Tools > ProBuilder > Materials menu](images/menu-materials.png)

Select the specific Material preset defined on the [Material Editor window](material-tools.md) to [set the associated Material](workflow-materials.md#apply) on the selected object(s) or element(s).

