# The `src/assets/common` Directory

this directory contains common assets and should not be modified in the project deriving from `unityeditor-cloud-base`.  Addition should be made instead to the master `unityeditor-cloud-base` project and merged back in derived projects instead.