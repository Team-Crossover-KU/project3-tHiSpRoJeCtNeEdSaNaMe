﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.CollabProxy.UI.Tests")]
