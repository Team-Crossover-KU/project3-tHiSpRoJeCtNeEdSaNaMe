﻿namespace CollabProxy.Models
{
    internal enum AsyncMessageType
    {
        FileSystemChanged
    }
}